﻿#pragma strict

public var points : int = 5;
public var pickedUpBy : String = "Player";
/* 
Public variables will 
show up in Unity Editor
*/

function OnTriggerEnter2D(other : Collider2D)// checks for collisions
	{
		if (other.CompareTag(pickedUpBy) ) //if there is collision, do these two things:
		{
			Debug.Log("Coins! You suck! " + points + "points!"); //give 5 points

			Destroy(gameObject); //destroy oneself

	}

}